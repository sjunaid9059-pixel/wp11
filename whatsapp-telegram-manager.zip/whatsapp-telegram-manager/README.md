# WhatsApp Multi-Account Manager – Telegram Bot + Mini App

**Production-oriented starter** for managing **your own** WhatsApp accounts via a premium Telegram Mini App.

> ⚠️ **Legal & Ethical Notice**  
> This project is intended **only** for WhatsApp accounts that **you personally own or are explicitly authorized to manage**.  
> It uses official multi-device linking (QR or Pairing Code).  
> It does **NOT** steal credentials, intercept OTPs, provide hidden access, or allow unauthorized account takeover.  
> Misuse against WhatsApp Terms of Service can result in permanent bans. Use responsibly.

## Features

- **Two login methods**
  - **QR Login** – classic Linked Devices scan
  - **Phone Number + Pairing Code** – enter number → get 8-character code → enter it yourself in WhatsApp → Linked Devices → Link with phone number  
    *(There is no SMS OTP interception. Baileys multi-device uses pairing code, not SMS OTP.)*
- **Strict per-Telegram-user isolation**  
  Every session, auth folder, chat data and metadata is completely separated by `telegram_user_id`. User A can never see User B’s data.
- **Premium dark UI** Mini App (glassmorphism, Telegram theme colors, live QR / pairing code, status badges)
- Ready-to-extend architecture (session manager, WebSocket push, PostgreSQL-ready)

## Tech Stack

| Part              | Technology                          |
|-------------------|-------------------------------------|
| WhatsApp          | `@whiskeysockets/baileys`           |
| Backend           | Node.js 20+ / TypeScript / Fastify  |
| Telegram Bot      | Grammy                              |
| Mini App          | React + Vite + Tailwind + Telegram WebApp SDK |
| Auth isolation    | Telegram `initData` HMAC validation |
| Session storage   | `useMultiFileAuthState` (per user folder) |

## Project Structure

```
whatsapp-telegram-manager/
├── backend/                 # API + Bot + Baileys manager
│   ├── src/
│   │   ├── index.ts
│   │   ├── bot.ts
│   │   ├── whatsapp/
│   │   │   ├── manager.ts
│   │   │   └── session.ts
│   │   ├── routes/
│   │   ├── middleware/
│   │   └── utils/
│   ├── package.json
│   ├── tsconfig.json
│   └── .env.example
├── mini-app/                # Telegram Mini App (React)
│   ├── src/
│   │   ├── App.tsx
│   │   ├── components/
│   │   ├── pages/
│   │   ├── hooks/
│   │   └── lib/
│   ├── package.json
│   ├── vite.config.ts
│   └── tailwind.config.js
├── docs/
└── README.md
```

## Quick Start

### 1. Prerequisites
- Node.js ≥ 20
- A Telegram Bot token from @BotFather
- HTTPS domain (required for Mini App in production). For local testing use ngrok / Cloudflare Tunnel.

### 2. Backend

```bash
cd backend
cp .env.example .env
# Edit .env → put BOT_TOKEN and other values
npm install
npm run dev
```

### 3. Mini App

```bash
cd mini-app
npm install
npm run dev
```

### 4. BotFather Setup
1. `/newbot` → get token
2. `/setmenubutton` or send a message with `web_app` button pointing to your Mini App URL (must be HTTPS)
3. For local: use ngrok and set the public HTTPS URL

### 5. Environment Variables (`backend/.env`)

```env
BOT_TOKEN=123456:ABC-DEF...
PORT=3000
MINI_APP_URL=https://your-domain.com
JWT_SECRET=change-me-to-a-long-random-string
SESSIONS_DIR=./sessions
NODE_ENV=development
```

## How Login Works

### QR Login
1. User clicks “Add Account” → chooses QR
2. Backend creates isolated Baileys socket for that Telegram user + new accountId
3. QR is pushed via WebSocket to the Mini App
4. User opens WhatsApp → Linked Devices → Link a Device → scans QR
5. On `connection === 'open'` status becomes Connected and session is saved

### Phone + Pairing Code
1. User chooses “Phone Number”
2. Enters own number (with country code)
3. Backend calls `sock.requestPairingCode(normalizedNumber)`
4. 8-character code is shown in the Mini App
5. User goes to WhatsApp → Linked Devices → Link with phone number → enters the code
6. Session is saved automatically

**Note**: This is **not** SMS OTP login. WhatsApp multi-device linking never sends an SMS OTP to the companion device flow.

## Security Notes

- Every request validates Telegram `initData` (HMAC-SHA256 with bot token).
- Auth state folders: `sessions/{telegramUserId}/{accountId}/`
- Never return raw creds or session files to the client.
- WebSocket rooms are keyed by `telegramUserId` only.
- Always sanitize phone numbers server-side.

## Extending to Production

- Add PostgreSQL for account metadata
- Encrypt session folders at rest
- Use Redis for multi-instance socket coordination
- Add proper reconnect + 515 handling
- Rate-limit account creation per user
- Media download / message sync (optional)
- Proper process manager (PM2) + auto-restart of existing sessions

## Disclaimer

This is a **starter / educational** codebase.  
Running many unofficial WhatsApp Web sessions can lead to rate-limits or bans.  
Use only on accounts you own. The authors take no responsibility for misuse or account bans.

---

Made for authorized personal multi-account management only.
