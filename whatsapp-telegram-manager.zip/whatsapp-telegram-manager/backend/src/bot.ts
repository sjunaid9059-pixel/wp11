import { Bot, InlineKeyboard } from 'grammy'
import { config } from './config.js'

export function createBot() {
  const bot = new Bot(config.BOT_TOKEN)

  bot.command('start', async (ctx) => {
    const keyboard = new InlineKeyboard().webApp(
      '🚀 Open WhatsApp Manager',
      config.MINI_APP_URL
    )

    await ctx.reply(
      `👋 *WhatsApp Multi-Account Manager*\n\n` +
        `Manage your *own* WhatsApp accounts safely.\n\n` +
        `• QR Login\n` +
        `• Phone + Pairing Code\n` +
        `• Fully isolated sessions\n\n` +
        `Tap the button below to open the premium dashboard.`,
      {
        parse_mode: 'Markdown',
        reply_markup: keyboard,
      }
    )
  })

  bot.command('help', async (ctx) => {
    await ctx.reply(
      'This bot opens a Mini App dashboard where you can link WhatsApp accounts that *you own* using QR or pairing code.\n\n' +
        'No credentials are ever sent to Telegram.'
    )
  })

  bot.catch((err) => {
    console.error('Bot error', err)
  })

  return bot
}
