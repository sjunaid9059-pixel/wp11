import { FastifyInstance } from 'fastify'
import { validateInitData, signUserToken, verifyUserToken, normalizePhone } from '../utils/telegram.js'
import { config } from '../config.js'
import { WhatsAppManager } from '../whatsapp/manager.js'

export async function registerApiRoutes(app: FastifyInstance, manager: WhatsAppManager) {
  // Auth: exchange initData for JWT
  app.post('/api/auth', async (req, reply) => {
    const { initData } = req.body as { initData?: string }
    if (!initData) return reply.code(400).send({ error: 'initData required' })

    const result = validateInitData(initData, config.BOT_TOKEN)
    if (!result.valid || !result.user?.id) {
      return reply.code(401).send({ error: 'Invalid initData' })
    }

    const telegramUserId = String(result.user.id)

    if (config.ALLOWED_TELEGRAM_IDS.length > 0 && !config.ALLOWED_TELEGRAM_IDS.includes(telegramUserId)) {
      return reply.code(403).send({ error: 'Not allowed' })
    }

    const token = signUserToken(telegramUserId, config.JWT_SECRET)
    return {
      token,
      user: {
        id: result.user.id,
        first_name: result.user.first_name,
        username: result.user.username,
      },
    }
  })

  // Helper to extract telegram user from JWT
  function getUserId(req: any): string | null {
    const auth = req.headers.authorization
    if (!auth?.startsWith('Bearer ')) return null
    const payload = verifyUserToken(auth.slice(7), config.JWT_SECRET)
    return payload?.telegramUserId || null
  }

  // List my accounts only
  app.get('/api/accounts', async (req, reply) => {
    const telegramUserId = getUserId(req)
    if (!telegramUserId) return reply.code(401).send({ error: 'Unauthorized' })

    const accounts = manager.listAccounts(telegramUserId)
    return { accounts }
  })

  // Start new QR login
  app.post('/api/accounts/qr', async (req, reply) => {
    const telegramUserId = getUserId(req)
    if (!telegramUserId) return reply.code(401).send({ error: 'Unauthorized' })

    const meta = await manager.createAccount(telegramUserId, { mode: 'qr' })
    return { account: meta }
  })

  // Start pairing-code login
  app.post('/api/accounts/pairing', async (req, reply) => {
    const telegramUserId = getUserId(req)
    if (!telegramUserId) return reply.code(401).send({ error: 'Unauthorized' })

    const { phoneNumber } = req.body as { phoneNumber?: string }
    const normalized = phoneNumber ? normalizePhone(phoneNumber) : null
    if (!normalized) {
      return reply.code(400).send({ error: 'Valid phone number with country code required' })
    }

    const meta = await manager.createAccount(telegramUserId, {
      mode: 'pairing',
      phoneNumber: normalized,
    })
    return { account: meta }
  })

  // Logout / delete one of my accounts
  app.delete('/api/accounts/:accountId', async (req, reply) => {
    const telegramUserId = getUserId(req)
    if (!telegramUserId) return reply.code(401).send({ error: 'Unauthorized' })

    const { accountId } = req.params as { accountId: string }
    const ok = await manager.logoutAccount(telegramUserId, accountId)
    if (!ok) return reply.code(404).send({ error: 'Account not found' })
    return { success: true }
  })
}
