import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  Browsers,
  WASocket,
} from '@whiskeysockets/baileys'
import { Boom } from '@hapi/boom'
import QRCode from 'qrcode'
import path from 'path'
import fs from 'fs/promises'
import { EventEmitter } from 'events'
import { v4 as uuidv4 } from 'uuid'

export type AccountStatus = 'connecting' | 'qr' | 'pairing' | 'connected' | 'disconnected' | 'logged_out'

export interface AccountMeta {
  accountId: string
  telegramUserId: string
  phone?: string
  status: AccountStatus
  jid?: string
  name?: string
  createdAt: number
  lastQr?: string          // data URL
  pairingCode?: string
}

export class WhatsAppSession extends EventEmitter {
  public readonly accountId: string
  public readonly telegramUserId: string
  public meta: AccountMeta
  private sock: WASocket | null = null
  private authDir: string
  private sessionsRoot: string
  private reconnectAttempts = 0

  constructor(telegramUserId: string, sessionsRoot: string, existingAccountId?: string) {
    super()
    this.telegramUserId = telegramUserId
    this.sessionsRoot = sessionsRoot
    this.accountId = existingAccountId || uuidv4()
    this.authDir = path.join(sessionsRoot, telegramUserId, this.accountId)
    this.meta = {
      accountId: this.accountId,
      telegramUserId,
      status: 'connecting',
      createdAt: Date.now(),
    }
  }

  async start(options: { mode: 'qr' | 'pairing'; phoneNumber?: string }) {
    await fs.mkdir(this.authDir, { recursive: true })

    const { state, saveCreds } = await useMultiFileAuthState(this.authDir)

    this.sock = makeWASocket({
      auth: state,
      browser: Browsers.ubuntu('Chrome'),
      printQRInTerminal: false,
      syncFullHistory: false,
      markOnlineOnConnect: false,
    })

    this.sock.ev.on('creds.update', saveCreds)

    this.sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect, qr } = update

      if (qr && options.mode === 'qr') {
        try {
          const dataUrl = await QRCode.toDataURL(qr, { margin: 2, width: 320 })
          this.meta.status = 'qr'
          this.meta.lastQr = dataUrl
          this.emit('update', { ...this.meta })
        } catch (e) {
          console.error('QR generation failed', e)
        }
      }

      if (connection === 'open') {
        this.reconnectAttempts = 0
        this.meta.status = 'connected'
        this.meta.jid = this.sock?.user?.id
        this.meta.name = this.sock?.user?.name || this.sock?.user?.verifiedName
        this.meta.lastQr = undefined
        this.meta.pairingCode = undefined
        this.emit('update', { ...this.meta })
        this.emit('connected', { ...this.meta })
      }

      if (connection === 'close') {
        const statusCode = (lastDisconnect?.error as Boom)?.output?.statusCode
        const loggedOut = statusCode === DisconnectReason.loggedOut

        if (loggedOut) {
          this.meta.status = 'logged_out'
          this.emit('update', { ...this.meta })
          await this.destroy()
          return
        }

        // Simple reconnect with backoff
        this.meta.status = 'disconnected'
        this.emit('update', { ...this.meta })

        if (this.reconnectAttempts < 5) {
          this.reconnectAttempts++
          const delay = Math.min(1000 * 2 ** this.reconnectAttempts, 30000)
          setTimeout(() => {
            this.start(options).catch(console.error)
          }, delay)
        }
      }
    })

    // Pairing code path
    if (options.mode === 'pairing' && options.phoneNumber) {
      const number = options.phoneNumber.replace(/\D/g, '')
      this.meta.phone = number

      // Wait a short moment for socket to be ready, then request code
      // In practice you can also listen for the first connection.update with qr
      setTimeout(async () => {
        try {
          if (!this.sock?.authState?.creds?.registered) {
            const code = await this.sock!.requestPairingCode(number)
            this.meta.status = 'pairing'
            this.meta.pairingCode = code
            this.emit('update', { ...this.meta })
          }
        } catch (err) {
          console.error('requestPairingCode failed', err)
          this.meta.status = 'disconnected'
          this.emit('update', { ...this.meta })
        }
      }, 1500)
    }

    return this
  }

  async logout() {
    try {
      await this.sock?.logout()
    } catch {}
    await this.destroy()
  }

  async destroy() {
    try {
      this.sock?.end(undefined)
    } catch {}
    this.sock = null
    try {
      await fs.rm(this.authDir, { recursive: true, force: true })
    } catch {}
    this.meta.status = 'logged_out'
    this.emit('destroyed', this.accountId)
  }

  getSocket() {
    return this.sock
  }
}
