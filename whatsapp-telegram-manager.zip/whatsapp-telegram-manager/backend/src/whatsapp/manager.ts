import { WhatsAppSession, AccountMeta } from './session.js'
import path from 'path'
import fs from 'fs/promises'
import { EventEmitter } from 'events'

/**
 * Global session manager with strict per-Telegram-user isolation.
 * User A can never access User B's sockets or auth folders.
 */
export class WhatsAppManager extends EventEmitter {
  private sessions = new Map<string, Map<string, WhatsAppSession>>() // telegramUserId → accountId → session
  private sessionsRoot: string

  constructor(sessionsRoot: string) {
    super()
    this.sessionsRoot = sessionsRoot
  }

  private getUserMap(telegramUserId: string) {
    if (!this.sessions.has(telegramUserId)) {
      this.sessions.set(telegramUserId, new Map())
    }
    return this.sessions.get(telegramUserId)!
  }

  async createAccount(
    telegramUserId: string,
    options: { mode: 'qr' | 'pairing'; phoneNumber?: string }
  ): Promise<AccountMeta> {
    const session = new WhatsAppSession(telegramUserId, this.sessionsRoot)
    const userMap = this.getUserMap(telegramUserId)
    userMap.set(session.accountId, session)

    session.on('update', (meta: AccountMeta) => {
      this.emit('account_update', meta)
    })

    session.on('destroyed', (accountId: string) => {
      userMap.delete(accountId)
      this.emit('account_destroyed', { telegramUserId, accountId })
    })

    await session.start(options)
    return session.meta
  }

  listAccounts(telegramUserId: string): AccountMeta[] {
    const userMap = this.getUserMap(telegramUserId)
    return Array.from(userMap.values()).map((s) => ({ ...s.meta }))
  }

  getAccount(telegramUserId: string, accountId: string): WhatsAppSession | null {
    return this.getUserMap(telegramUserId).get(accountId) || null
  }

  async logoutAccount(telegramUserId: string, accountId: string) {
    const session = this.getAccount(telegramUserId, accountId)
    if (!session) return false
    await session.logout()
    return true
  }

  async restoreExistingSessions() {
    // On server start, scan sessions/{telegramUserId}/{accountId} and re-create sockets
    try {
      const users = await fs.readdir(this.sessionsRoot).catch(() => [])
      for (const telegramUserId of users) {
        const userDir = path.join(this.sessionsRoot, telegramUserId)
        const accounts = await fs.readdir(userDir).catch(() => [])
        for (const accountId of accounts) {
          const session = new WhatsAppSession(telegramUserId, this.sessionsRoot, accountId)
          this.getUserMap(telegramUserId).set(accountId, session)

          session.on('update', (meta) => this.emit('account_update', meta))
          session.on('destroyed', (id) => {
            this.getUserMap(telegramUserId).delete(id)
          })

          // Reconnect with QR mode (will use existing creds if present)
          await session.start({ mode: 'qr' }).catch(console.error)
        }
      }
      console.log(`Restored sessions for ${users.length} users`)
    } catch (e) {
      console.error('Failed to restore sessions', e)
    }
  }
}
