import 'dotenv/config'
import path from 'path'

function required(name: string): string {
  const v = process.env[name]
  if (!v) throw new Error(`Missing required env: ${name}`)
  return v
}

export const config = {
  BOT_TOKEN: required('BOT_TOKEN'),
  PORT: Number(process.env.PORT || 3000),
  HOST: process.env.HOST || '0.0.0.0',
  MINI_APP_URL: process.env.MINI_APP_URL || 'http://localhost:5173',
  JWT_SECRET: required('JWT_SECRET'),
  SESSIONS_DIR: path.resolve(process.env.SESSIONS_DIR || './sessions'),
  NODE_ENV: process.env.NODE_ENV || 'development',
  ALLOWED_TELEGRAM_IDS: (process.env.ALLOWED_TELEGRAM_IDS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),
}
