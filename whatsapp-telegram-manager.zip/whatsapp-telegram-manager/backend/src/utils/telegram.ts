import crypto from 'crypto'
import jwt from 'jsonwebtoken'

/**
 * Validates Telegram Mini App initData according to official docs.
 * https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
 */
export function validateInitData(initData: string, botToken: string): { valid: boolean; user?: any; authDate?: number } {
  try {
    const params = new URLSearchParams(initData)
    const hash = params.get('hash')
    if (!hash) return { valid: false }

    params.delete('hash')
    const dataCheckString = Array.from(params.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([k, v]) => `${k}=${v}`)
      .join('\n')

    const secretKey = crypto
      .createHmac('sha256', 'WebAppData')
      .update(botToken)
      .digest()

    const calculatedHash = crypto
      .createHmac('sha256', secretKey)
      .update(dataCheckString)
      .digest('hex')

    if (calculatedHash !== hash) return { valid: false }

    const userStr = params.get('user')
    const authDate = Number(params.get('auth_date') || 0)

    // Optional: reject if older than 1 day
    if (Date.now() / 1000 - authDate > 86400) {
      return { valid: false }
    }

    const user = userStr ? JSON.parse(userStr) : undefined
    return { valid: true, user, authDate }
  } catch {
    return { valid: false }
  }
}

export function signUserToken(telegramUserId: number | string, secret: string, expiresIn = '7d') {
  return jwt.sign(
    { sub: String(telegramUserId), type: 'telegram_user' },
    secret,
    { expiresIn }
  )
}

export function verifyUserToken(token: string, secret: string): { telegramUserId: string } | null {
  try {
    const payload = jwt.verify(token, secret) as any
    if (payload.type !== 'telegram_user' || !payload.sub) return null
    return { telegramUserId: String(payload.sub) }
  } catch {
    return null
  }
}

export function normalizePhone(input: string): string | null {
  const digits = input.replace(/\D/g, '')
  if (digits.length < 10 || digits.length > 15) return null
  return digits
}
