import Fastify from 'fastify'
import cors from '@fastify/cors'
import websocket from '@fastify/websocket'
import { config } from './config.js'
import { createBot } from './bot.js'
import { WhatsAppManager } from './whatsapp/manager.js'
import { registerApiRoutes } from './routes/api.js'
import { verifyUserToken } from './utils/telegram.js'
import fs from 'fs/promises'

async function main() {
  await fs.mkdir(config.SESSIONS_DIR, { recursive: true })

  const manager = new WhatsAppManager(config.SESSIONS_DIR)
  await manager.restoreExistingSessions()

  const app = Fastify({ logger: true })

  await app.register(cors, {
    origin: true,
    credentials: true,
  })

  await app.register(websocket)

  // Simple WebSocket for live account updates (per user)
  // Client connects with ?token=JWT
  app.get('/ws', { websocket: true }, (socket, req) => {
    const url = new URL(req.url || '', `http://${req.headers.host}`)
    const token = url.searchParams.get('token')
    if (!token) {
      socket.close(4001, 'token required')
      return
    }

    const payload = verifyUserToken(token, config.JWT_SECRET)
    if (!payload) {
      socket.close(4001, 'invalid token')
      return
    }

    const telegramUserId = payload.telegramUserId
    console.log(`WS connected: ${telegramUserId}`)

    const onUpdate = (meta: any) => {
      if (meta.telegramUserId === telegramUserId) {
        socket.send(JSON.stringify({ type: 'account_update', account: meta }))
      }
    }

    manager.on('account_update', onUpdate)

    socket.on('close', () => {
      manager.off('account_update', onUpdate)
    })

    // Send current list on connect
    const accounts = manager.listAccounts(telegramUserId)
    socket.send(JSON.stringify({ type: 'accounts', accounts }))
  })

  await registerApiRoutes(app, manager)

  // Health
  app.get('/health', async () => ({ ok: true }))

  // Start Telegram bot
  const bot = createBot()
  bot.start({
    onStart: (info) => console.log(`Bot @${info.username} started`),
  })

  await app.listen({ port: config.PORT, host: config.HOST })
  console.log(`API listening on http://${config.HOST}:${config.PORT}`)
  console.log(`Mini App URL: ${config.MINI_APP_URL}`)
}

main().catch((err) => {
  console.error(err)
  process.exit(1)
})
