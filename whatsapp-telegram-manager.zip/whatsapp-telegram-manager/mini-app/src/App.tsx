import { useEffect, useState, useCallback } from 'react'
import { authenticate, listAccounts, connectWebSocket, clearToken } from './lib/api'
import { Header } from './components/Header'
import { AccountCard } from './components/AccountCard'
import { AddAccountModal } from './components/AddAccountModal'
import { Plus, Loader2, ShieldCheck } from 'lucide-react'

declare global {
  interface Window {
    Telegram?: {
      WebApp: any
    }
  }
}

export interface Account {
  accountId: string
  telegramUserId: string
  phone?: string
  status: string
  jid?: string
  name?: string
  createdAt: number
  lastQr?: string
  pairingCode?: string
}

export default function App() {
  const [ready, setReady] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [accounts, setAccounts] = useState<Account[]>([])
  const [showAdd, setShowAdd] = useState(false)
  const [user, setUser] = useState<any>(null)

  const tg = window.Telegram?.WebApp

  useEffect(() => {
    if (tg) {
      tg.ready()
      tg.expand()
      tg.setHeaderColor('#0f0f0f')
      tg.setBackgroundColor('#0f0f0f')
    }
  }, [tg])

  const refresh = useCallback(async () => {
    try {
      const { accounts } = await listAccounts()
      setAccounts(accounts)
    } catch (e: any) {
      console.error(e)
    }
  }, [])

  useEffect(() => {
    async function init() {
      try {
        const initData = tg?.initData || ''
        if (!initData && import.meta.env.DEV) {
          // Dev fallback – replace with real initData in production
          setError('Open this Mini App from Telegram (or provide mock initData in dev)')
          setLoading(false)
          return
        }

        const auth = await authenticate(initData)
        setUser(auth.user)

        await refresh()

        // Live updates
        connectWebSocket((msg) => {
          if (msg.type === 'accounts') {
            setAccounts(msg.accounts)
          }
          if (msg.type === 'account_update') {
            setAccounts((prev) => {
              const idx = prev.findIndex((a) => a.accountId === msg.account.accountId)
              if (idx >= 0) {
                const next = [...prev]
                next[idx] = msg.account
                return next
              }
              return [...prev, msg.account]
            })
          }
        })

        setReady(true)
      } catch (e: any) {
        setError(e.message || 'Authentication failed')
        clearToken()
      } finally {
        setLoading(false)
      }
    }
    init()
  }, [tg, refresh])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-400" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center">
        <ShieldCheck className="w-12 h-12 text-red-400 mb-4" />
        <h1 className="text-xl font-semibold mb-2">Access Error</h1>
        <p className="text-tg-hint text-sm max-w-xs">{error}</p>
        <p className="text-tg-hint text-xs mt-4">Open this page from the Telegram bot menu.</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen pb-24">
      <Header user={user} />

      <main className="px-4 pt-4 max-w-lg mx-auto space-y-4">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-semibold">Your WhatsApp Accounts</h2>
          <span className="text-xs text-tg-hint">{accounts.length} linked</span>
        </div>

        {accounts.length === 0 && (
          <div className="glass rounded-2xl p-8 text-center">
            <p className="text-tg-hint mb-4">No accounts linked yet</p>
            <p className="text-sm text-tg-hint">
              Add your own WhatsApp account using QR or Pairing Code
            </p>
          </div>
        )}

        {accounts.map((acc) => (
          <AccountCard key={acc.accountId} account={acc} onChange={refresh} />
        ))}
      </main>

      {/* Floating Add button */}
      <button
        onClick={() => setShowAdd(true)}
        className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-blue-500 text-white shadow-lg shadow-blue-500/30 flex items-center justify-center active:scale-95 transition"
      >
        <Plus className="w-6 h-6" />
      </button>

      {showAdd && (
        <AddAccountModal
          onClose={() => setShowAdd(false)}
          onCreated={() => {
            setShowAdd(false)
            refresh()
          }}
        />
      )}
    </div>
  )
}
