import { useState } from 'react'
import { Account } from '../App'
import { logoutAccount } from '../lib/api'
import { Trash2, Loader2, QrCode, KeyRound } from 'lucide-react'

const statusClass: Record<string, string> = {
  connected: 'badge-connected',
  qr: 'badge-qr',
  pairing: 'badge-pairing',
  connecting: 'badge-connecting',
  disconnected: 'badge-disconnected',
  logged_out: 'badge-disconnected',
}

export function AccountCard({ account, onChange }: { account: Account; onChange: () => void }) {
  const [busy, setBusy] = useState(false)

  async function handleLogout() {
    if (!confirm('Logout and delete this WhatsApp session?')) return
    setBusy(true)
    try {
      await logoutAccount(account.accountId)
      onChange()
    } catch (e: any) {
      alert(e.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="glass rounded-2xl p-4 space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-medium truncate">
            {account.name || account.phone || account.jid || 'New Account'}
          </p>
          {account.phone && (
            <p className="text-xs text-tg-hint">+{account.phone}</p>
          )}
          {account.jid && (
            <p className="text-xs text-tg-hint truncate">{account.jid}</p>
          )}
        </div>
        <span className={`text-[11px] px-2.5 py-1 rounded-full capitalize ${statusClass[account.status] || 'badge-connecting'}`}>
          {account.status.replace('_', ' ')}
        </span>
      </div>

      {/* Live QR */}
      {account.status === 'qr' && account.lastQr && (
        <div className="flex flex-col items-center gap-2 py-2">
          <div className="p-3 bg-white rounded-xl">
            <img src={account.lastQr} alt="QR Code" className="w-48 h-48" />
          </div>
          <p className="text-xs text-tg-hint flex items-center gap-1">
            <QrCode className="w-3.5 h-3.5" />
            Scan with WhatsApp → Linked Devices
          </p>
        </div>
      )}

      {/* Pairing code */}
      {account.status === 'pairing' && account.pairingCode && (
        <div className="flex flex-col items-center gap-2 py-3">
          <p className="text-xs text-tg-hint flex items-center gap-1">
            <KeyRound className="w-3.5 h-3.5" />
            Enter this code in WhatsApp
          </p>
          <div className="text-3xl font-bold tracking-[0.3em] text-violet-300 bg-violet-500/10 px-6 py-3 rounded-xl border border-violet-500/20">
            {account.pairingCode}
          </div>
          <p className="text-[11px] text-tg-hint text-center max-w-[240px]">
            WhatsApp → Linked Devices → Link with phone number
          </p>
        </div>
      )}

      <div className="flex justify-end pt-1">
        <button
          onClick={handleLogout}
          disabled={busy}
          className="flex items-center gap-1.5 text-xs text-red-400/80 hover:text-red-400 transition px-2 py-1.5 rounded-lg hover:bg-red-500/10"
        >
          {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
          Logout
        </button>
      </div>
    </div>
  )
}
