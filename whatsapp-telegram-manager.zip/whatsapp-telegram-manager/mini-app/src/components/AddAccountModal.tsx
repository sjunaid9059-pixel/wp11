import { useState } from 'react'
import { startQrLogin, startPairingLogin } from '../lib/api'
import { X, QrCode, Phone, Loader2 } from 'lucide-react'

export function AddAccountModal({
  onClose,
  onCreated,
}: {
  onClose: () => void
  onCreated: () => void
}) {
  const [step, setStep] = useState<'choose' | 'phone'>('choose')
  const [phone, setPhone] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleQr() {
    setLoading(true)
    setError(null)
    try {
      await startQrLogin()
      onCreated()
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  async function handlePairing() {
    if (!phone.trim()) {
      setError('Enter phone number with country code')
      return
    }
    setLoading(true)
    setError(null)
    try {
      await startPairingLogin(phone.trim())
      onCreated()
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md glass rounded-t-3xl sm:rounded-3xl p-5 pb-8 space-y-4 animate-in slide-in-from-bottom">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Add WhatsApp Account</h3>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-white/10">
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-sm text-tg-hint">
          Only link accounts you own. Sessions are completely isolated.
        </p>

        {error && (
          <div className="text-sm text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
            {error}
          </div>
        )}

        {step === 'choose' && (
          <div className="space-y-3">
            <button
              onClick={handleQr}
              disabled={loading}
              className="w-full flex items-center gap-4 p-4 rounded-2xl bg-blue-500/10 border border-blue-500/20 hover:bg-blue-500/20 transition text-left"
            >
              <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center">
                {loading ? <Loader2 className="w-6 h-6 animate-spin text-blue-400" /> : <QrCode className="w-6 h-6 text-blue-400" />}
              </div>
              <div>
                <p className="font-medium">QR Code Login</p>
                <p className="text-xs text-tg-hint">Scan with your phone camera</p>
              </div>
            </button>

            <button
              onClick={() => setStep('phone')}
              disabled={loading}
              className="w-full flex items-center gap-4 p-4 rounded-2xl bg-violet-500/10 border border-violet-500/20 hover:bg-violet-500/20 transition text-left"
            >
              <div className="w-12 h-12 rounded-xl bg-violet-500/20 flex items-center justify-center">
                <Phone className="w-6 h-6 text-violet-400" />
              </div>
              <div>
                <p className="font-medium">Phone + Pairing Code</p>
                <p className="text-xs text-tg-hint">Enter number → get 8-digit code</p>
              </div>
            </button>
          </div>
        )}

        {step === 'phone' && (
          <div className="space-y-4">
            <div>
              <label className="text-xs text-tg-hint mb-1.5 block">Phone number (with country code)</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="919876543210"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-base outline-none focus:border-violet-500/50 transition"
              />
              <p className="text-[11px] text-tg-hint mt-1.5">
                Example: 919876543210 (India) — no + or spaces
              </p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep('choose')}
                className="flex-1 py-3 rounded-xl bg-white/5 hover:bg-white/10 transition text-sm"
              >
                Back
              </button>
              <button
                onClick={handlePairing}
                disabled={loading}
                className="flex-1 py-3 rounded-xl bg-violet-500 hover:bg-violet-600 transition text-sm font-medium flex items-center justify-center gap-2"
              >
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                Get Pairing Code
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
