import { Smartphone } from 'lucide-react'

export function Header({ user }: { user: any }) {
  return (
    <header className="sticky top-0 z-20 glass border-b border-white/5 px-4 py-3">
      <div className="max-w-lg mx-auto flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-400 to-blue-500 flex items-center justify-center">
          <Smartphone className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="font-semibold text-base leading-tight">WhatsApp Manager</h1>
          <p className="text-xs text-tg-hint truncate">
            {user?.first_name || 'User'} {user?.username ? `(@${user.username})` : ''}
          </p>
        </div>
        <div className="text-[10px] px-2 py-1 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
          Isolated
        </div>
      </div>
    </header>
  )
}
