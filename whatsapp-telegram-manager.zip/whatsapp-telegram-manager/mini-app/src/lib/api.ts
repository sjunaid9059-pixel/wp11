const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:3000'

let authToken: string | null = null

export function setToken(token: string) {
  authToken = token
  localStorage.setItem('wa_token', token)
}

export function getToken() {
  if (authToken) return authToken
  return localStorage.getItem('wa_token')
}

export function clearToken() {
  authToken = null
  localStorage.removeItem('wa_token')
}

async function request(path: string, options: RequestInit = {}) {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as any),
  }
  const token = getToken()
  if (token) headers['Authorization'] = `Bearer ${token}`

  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
  })

  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }))
    throw new Error(err.error || 'Request failed')
  }
  return res.json()
}

export async function authenticate(initData: string) {
  const data = await request('/api/auth', {
    method: 'POST',
    body: JSON.stringify({ initData }),
  })
  setToken(data.token)
  return data
}

export async function listAccounts() {
  return request('/api/accounts')
}

export async function startQrLogin() {
  return request('/api/accounts/qr', { method: 'POST' })
}

export async function startPairingLogin(phoneNumber: string) {
  return request('/api/accounts/pairing', {
    method: 'POST',
    body: JSON.stringify({ phoneNumber }),
  })
}

export async function logoutAccount(accountId: string) {
  return request(`/api/accounts/${accountId}`, { method: 'DELETE' })
}

export function connectWebSocket(onMessage: (data: any) => void) {
  const token = getToken()
  if (!token) return null

  const wsUrl = API_BASE.replace(/^http/, 'ws') + `/ws?token=${token}`
  const ws = new WebSocket(wsUrl)

  ws.onmessage = (ev) => {
    try {
      const data = JSON.parse(ev.data)
      onMessage(data)
    } catch {}
  }

  ws.onclose = () => {
    // simple reconnect after 3s
    setTimeout(() => connectWebSocket(onMessage), 3000)
  }

  return ws
}
