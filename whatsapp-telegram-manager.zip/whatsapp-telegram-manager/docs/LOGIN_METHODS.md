# Login Methods Explained

## 1. QR Code (Linked Devices)

1. Backend creates a new Baileys socket with isolated auth folder.
2. QR string is generated and converted to a data-URL image.
3. Mini App shows the live QR.
4. User opens **WhatsApp → Linked Devices → Link a Device** and scans.
5. On successful link, status becomes `connected` and credentials are saved.

## 2. Phone Number + Pairing Code (NOT SMS OTP)

WhatsApp multi-device linking does **not** use SMS OTP for companion devices.

Instead:

1. User enters their own phone number (with country code).
2. Backend calls `sock.requestPairingCode(number)`.
3. An **8-character pairing code** is returned.
4. Mini App displays the code clearly.
5. User goes to **WhatsApp → Linked Devices → Link with phone number** and types the code.
6. Session is established and saved.

### Why no “number + OTP”?

- SMS OTP is used for primary device registration / 2FA recovery.
- Baileys (and official multi-device protocol) uses either QR or the pairing-code flow for linking a second device.
- This project **never** intercepts SMS, never steals OTPs, and never requests credentials.

If you see older bots asking for “OTP”, they are usually doing something unauthorized or using a completely different (and often banned) approach. This starter deliberately avoids that.
